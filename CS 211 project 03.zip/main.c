/*main.c*/

//
// Project 02: main program for execution of nuPython.
//
// Solution by Prof. Joe Hummel
// Northwestern University
// CS 211
//

// to eliminate warnings about stdlib in Visual Studio
#define _CRT_SECURE_NO_WARNINGS

#include <assert.h>
#include <stdbool.h> // true, false
#include <stdio.h>
#include <stdlib.h>
#include <string.h> // strcspn

#include "ast.h"        // builds AST representation
#include "parser.h"     // parser checks program syntax
#include "ram.h"        // memory for program execution
#include "scanner.h"    // scanner
#include "token.h"      // token defs
#include "tokenqueue.h" // program in token form
#include "util.h"       // panic

//
// all_zeros
//
// Returns true if the given string contains all 0 digits,
// false otherwise.
//
bool all_zeros(char *s) {
  for (int i = 0; i < strlen(s); i++)
    if (s[i] != '0')
      return false;

  return true;
}

//
// execute_assignment_function_call
//
// Executes assignment statements that contain a
// function call, returning true if execution is
// sucessful and false if not.
//
// Example: y = input("Enter an int>")
//          y = int(y)
//

static bool execute_assignment_function_call(struct AST_STMT *stmt,
                                             struct RAM *memory) {
  assert(stmt->stmt_type == AST_ASSIGNMENT);

  struct AST_STMT_ASSIGNMENT *assignment = stmt->types.assignment;
  char *variable_name = assignment->variable_name;

  assert(assignment->expr->expr_type == AST_FUNCTION_CALL_EXPR);

  char *function_name = assignment->expr->types.function_call->function_name;
  struct AST_EXPR *parameter = assignment->expr->types.function_call->param;

  //
  // functions have exactly one parameter that's a simple <element>
  // in the BNF, e.g. identifier or literal.
  //
  assert(parameter->expr_type == AST_UNARY_EXPR);

  struct AST_UNARY_EXPR *unary_expr = parameter->types.unary_expr;

  if (strcmp(function_name, "input") == 0) {
    //
    // x = input("...")
    //
    // 1. prompt the user:
    //
    if (unary_expr->unary_expr_type == AST_UNARY_EXPR_STR_LITERAL)
      printf("%s", unary_expr->types.literal_value);
    else
      panic("unsupported input() parameter unary expr type "
            "(execute_assignment_function_call)");

    //
    // 2. input from keyboard and assign to variable:
    //
    char line[256];
    fgets(line, sizeof(line), stdin);
    line[strcspn(line, "\r\n")] = '\0'; // delete EOL chars

    ram_write_str_by_id(memory, variable_name, line);
  } else if (strcmp(function_name, "int") == 0) {
    //
    // x = int(rhs)
    //
    if (unary_expr->unary_expr_type == AST_UNARY_EXPR_VARIABLE_ACCESS) {
      //
      // rhs => "right-hand-side", i.e. the variable on the rhs of =
      //
      char *rhs_var_name = parameter->types.unary_expr->types.variable_name;

      //
      // 1. retrieve rhs value
      //
      struct RAM_CELL *rhs_cell = ram_get_cell_by_id(memory, rhs_var_name);

      if (rhs_cell == NULL) {
        // no such variable:
        printf("ERROR: name '%s' is not defined\n", rhs_var_name);
        return false;
      }

      if (rhs_cell->ram_cell_type != RAM_TYPE_STR)
        panic("int() requires a string value (execute_assignment)");

      //
      // 2. value is a string, convert to int:
      //
      int value = atoi(rhs_cell->types.s);
      if (value == 0) {
        //
        // atoi() likely failed, but what if string is literally "0"?
        // check for this...
        //
        if (all_zeros(rhs_cell->types.s)) {
          // okay
        } else {
          printf("ERROR: invalid numeric string for int()\n");
          return false;
        }
      }

      //
      // 3. write to memory
      //
      ram_write_int_by_id(memory, variable_name, value);
    } else {
      panic("unsupported int(unary_expr_type) "
            "(execute_assignment_function_call)");
    }
  } else {
    panic("function not supported within assignment "
          "(execute_assignment_function_call)");
  }

  //
  // done, success:
  //
  return true;
}

//
// execute_assignment
//
// Executes assignment statements, returning true
// if execution is sucessful and false if not.
//
// Example: x = 123
//          y = input("Enter an int>")
//          y = int(y)
//          x = x + 1
//          z = y + 12
//

static bool execute_assignment(struct AST_STMT *stmt, struct RAM *memory) {
  assert(stmt->stmt_type == AST_ASSIGNMENT);

  struct AST_STMT_ASSIGNMENT *assignment = stmt->types.assignment;
  char *variable_name = assignment->variable_name;

  struct RAM_CELL *check = ram_get_cell_by_id(memory, variable_name);


  if (assignment->expr->expr_type == AST_UNARY_EXPR) {
    //
    // x = int_literal
    //
    struct AST_UNARY_EXPR *unary_expr = assignment->expr->types.unary_expr;

    if (unary_expr->unary_expr_type == AST_UNARY_EXPR_INT_LITERAL) {
      int value = atoi(unary_expr->types.literal_value);

      ram_write_int_by_id(memory, variable_name, value);
    }
    // if expression is a real ie. x = 1.234
    else if (unary_expr->unary_expr_type == AST_UNARY_EXPR_REAL_LITERAL) {
      double value = atof(unary_expr->types.literal_value);
      ram_write_real_by_id(memory, variable_name, value);
    }
    // if expression is a string ie. x = "hello"
    else if (unary_expr->unary_expr_type == AST_UNARY_EXPR_STR_LITERAL) {
      char *value = unary_expr->types.literal_value;
      ram_write_str_by_id(memory, variable_name, value);
    } else if (unary_expr->unary_expr_type == AST_UNARY_EXPR_VARIABLE_ACCESS) {
      char *variable_name2 = unary_expr->types.variable_name;
      // printf("variable_name2: %s\n", variable_name2);

      struct RAM_CELL *cell = ram_get_cell_by_id(memory, variable_name2);

      if (cell == NULL) {
        // no such variable:
        printf("ERROR: name '%s' is not defined\n", variable_name2);
        return false;
      }
      // if 2nd variable is of int type
      else if (cell->ram_cell_type == RAM_TYPE_INT) {
        ram_write_int_by_id(memory, variable_name, cell->types.i);
      }
      // if 2nd variable is of real type
      else if (cell->ram_cell_type == RAM_TYPE_REAL) {
        ram_write_real_by_id(memory, variable_name, cell->types.d);
      }
      // if 2nd variable is of string type
      else if (cell->ram_cell_type == RAM_TYPE_STR) {
        ram_write_str_by_id(memory, variable_name, cell->types.s);
      }
    } else {
      panic("assignment unary_expr_type not supported (execute_assignment)");
    }
  } else if (assignment->expr->expr_type == AST_BINARY_EXPR) {
    //
    // variable_name = other_var_name + int_literal
    //
    struct AST_BINARY_EXPR *binary_expr = assignment->expr->types.binary_expr;

    struct AST_UNARY_EXPR *lhs_expr = binary_expr->lhs;
    struct AST_UNARY_EXPR *rhs_expr = binary_expr->rhs;

    if (binary_expr->op == AST_BINARY_EXPR_PLUS) {
      if (lhs_expr->unary_expr_type == AST_UNARY_EXPR_VARIABLE_ACCESS &&
          (rhs_expr->unary_expr_type == AST_UNARY_EXPR_INT_LITERAL ||
           rhs_expr->unary_expr_type == AST_UNARY_EXPR_REAL_LITERAL)) {
        //
        // other_var_name + literal_value
        //
        char *other_var_name = lhs_expr->types.variable_name;
        char *literal_value = rhs_expr->types.literal_value;

        //
        // 1. retrieve other_var_name value
        //
        struct RAM_CELL *cell = ram_get_cell_by_id(memory, other_var_name);

        if (cell == NULL) {
          // no such variable:
          printf("ERROR: name '%s' is not defined\n", other_var_name);
          return false;
        } else if (cell->ram_cell_type != RAM_TYPE_INT &&
                   cell->ram_cell_type != RAM_TYPE_REAL) {
          printf("ERROR: unsupported operand type(s) for + \n");
          return false;
        } else if (rhs_expr->unary_expr_type == AST_UNARY_EXPR_INT_LITERAL &&
                   cell->ram_cell_type == RAM_TYPE_INT) {
          int value = atoi(literal_value);
          value = cell->types.i + value;
          ram_write_int_by_id(memory, variable_name, value);
        }
        //
        // 2. convert the literal value
        //
        else if (cell->ram_cell_type == RAM_TYPE_INT) {

          double value = atof(literal_value);
          value = cell->types.i + value;
          ram_write_real_by_id(memory, variable_name, value);
        } else {
          double value = atof(literal_value);
          value = cell->types.d + value;
          ram_write_real_by_id(memory, variable_name, value);
        }
        //
        // 3. add
        //
        //
        // 4. variable_name = value
        //
        // ram_write_int_by_id(memory, variable_name, value);
      } else if (lhs_expr->unary_expr_type == AST_UNARY_EXPR_VARIABLE_ACCESS &&
                 rhs_expr->unary_expr_type == AST_UNARY_EXPR_STR_LITERAL) {
        char *other_var_name = lhs_expr->types.variable_name;
        char *literal_value = rhs_expr->types.literal_value;
        //
        // 1. retrieve other_var_name value
        //
        struct RAM_CELL *cell2 = ram_get_cell_by_id(memory, other_var_name);

        if (cell2 == NULL) {
          // no such variable:
          printf("ERROR: name '%s' is not defined\n", other_var_name);
          return false;
        } else if (cell2->ram_cell_type != RAM_TYPE_STR) {
          printf("ERROR: unsupported operand type(s) for + \n");
          return false;
        } else {
          char *value =
              (char *)malloc(sizeof(char) * (strlen(cell2->types.s) +
                                             strlen(literal_value) + 1));
          strcpy(value, cell2->types.s);
          strcat(value, literal_value);
          ram_write_str_by_id(memory, variable_name, value);
          free(value);
        }
      } else if (lhs_expr->unary_expr_type == AST_UNARY_EXPR_VARIABLE_ACCESS &&
                 rhs_expr->unary_expr_type == AST_UNARY_EXPR_VARIABLE_ACCESS) {
        char *variable_name2 = lhs_expr->types.variable_name;
        char *variable_name3 = rhs_expr->types.variable_name;

        struct RAM_CELL *lhs_cell = ram_get_cell_by_id(memory, variable_name2);
        struct RAM_CELL *rhs_cell = ram_get_cell_by_id(memory, variable_name3);

        if (lhs_cell == NULL) {
          printf("ERROR: name '%s' is not defined\n", variable_name2);
          return false;
        }
        if(rhs_cell == NULL){
          printf("ERROR: name '%s' is not defined\n", variable_name3);
          return false;
        }
        if (lhs_cell->ram_cell_type == RAM_TYPE_INT && rhs_cell->ram_cell_type == RAM_TYPE_INT) {
          int value = lhs_cell->types.i + rhs_cell->types.i;
          ram_write_int_by_id(memory, variable_name, value);
        } else if (lhs_cell->ram_cell_type == RAM_TYPE_REAL && rhs_cell->ram_cell_type == RAM_TYPE_INT) {
          double value = lhs_cell->types.d + rhs_cell->types.i;
          ram_write_real_by_id(memory, variable_name, value);
        } else if (lhs_cell->ram_cell_type == RAM_TYPE_INT && rhs_cell->ram_cell_type == RAM_TYPE_REAL) {
          double value = lhs_cell->types.i + rhs_cell->types.d;
          ram_write_real_by_id(memory, variable_name, value);
        } else if (lhs_cell->ram_cell_type == RAM_TYPE_REAL && rhs_cell->ram_cell_type == RAM_TYPE_REAL) {
          double value = lhs_cell->types.d + rhs_cell->types.d;
          ram_write_real_by_id(memory, variable_name, value);
        } else if (lhs_cell->ram_cell_type == RAM_TYPE_STR && rhs_cell->ram_cell_type == RAM_TYPE_STR) {
          char *value =
              (char *)malloc(sizeof(char) * (strlen(lhs_cell->types.s) +
                                             strlen(rhs_cell->types.s) + 1));
          strcpy(value, lhs_cell->types.s);
          strcat(value, rhs_cell->types.s);
          ram_write_str_by_id(memory, variable_name, value);
          free(value);
        }

      } else {
        panic("assignment unary_expr_type not supported (execute_assignment)");
      }

    } else {
      panic("unsupported binary expression (execute_assignment)");
    }
  }

  else if (assignment->expr->expr_type == AST_FUNCTION_CALL_EXPR) {
    bool success = execute_assignment_function_call(stmt, memory);

    if (!success)
      return false;
  } else {
    panic("assignment expr_type not supported (execute_assignment)");
  }

  //
  // done, success:
  //
  return true;
}

//
// execute_function_call
//
// Executes the stmt denoting a function call, such as print(...).
// Returns true if successful, false if not.
//
// Example: print("a string")
//          print(123)
//          print(x)
//
static bool execute_function_call(struct AST_STMT *stmt, struct RAM *memory) {
  assert(stmt->stmt_type == AST_FUNCTION_CALL);

  char *function_name = stmt->types.function_call->function_name;
  struct AST_EXPR *parameter = stmt->types.function_call->param;

  //
  // functions have exactly one parameter that's a simple <element>
  // in the BNF, e.g. identifier or literal.
  //
  assert(parameter->expr_type == AST_UNARY_EXPR);

  struct AST_UNARY_EXPR *unary_expr = parameter->types.unary_expr;

  if (strcmp(function_name, "print") == 0) {
    //
    // execute print(???)
    //
    if (unary_expr->unary_expr_type == AST_UNARY_EXPR_INT_LITERAL ||
        unary_expr->unary_expr_type == AST_UNARY_EXPR_REAL_LITERAL ||
        unary_expr->unary_expr_type == AST_UNARY_EXPR_STR_LITERAL) {
      //
      // print(literal)
      //

      printf("%s\n", unary_expr->types.literal_value);
    } else if (unary_expr->unary_expr_type == AST_UNARY_EXPR_VARIABLE_ACCESS) {
      //
      // print(variable)
      //
      char *identifier = unary_expr->types.variable_name;

      struct RAM_CELL *memory_cell = ram_get_cell_by_id(memory, identifier);
      if (memory_cell == NULL) {
        printf("ERROR: name '%s' is not defined\n", identifier);
        return false;
      } else if (memory_cell->ram_cell_type == RAM_TYPE_INT)
        printf("%d\n", memory_cell->types.i);
      else if (memory_cell->ram_cell_type == RAM_TYPE_REAL)
        printf("%lf\n", memory_cell->types.d);
      else if (memory_cell->ram_cell_type == RAM_TYPE_STR)
        printf("%s\n", memory_cell->types.s);
      else
        panic("unsupported variable type (execute_function_call)");
    } else {
      panic("unsupported print(unary_expr_type) (execute_function_call)");
    }
  } else {
    panic("unsupported function (execute_function_call)");
  }

  //
  // done, success:
  //
  return true;
}

static int evaluate_while_cond(struct AST_EXPR *cond, struct RAM *memory) {
  // Extract components of the binary expression in the condition
  struct AST_BINARY_EXPR *be = cond->types.binary_expr;
  struct AST_UNARY_EXPR *lhs = be->lhs;
  struct AST_UNARY_EXPR *rhs = be->rhs;

  // Check whether the left-hand side (lhs) is a variable access
  bool is_lhs_as = lhs->unary_expr_type == AST_UNARY_EXPR_VARIABLE_ACCESS;

  // Check the right-hand side (rhs) for int, real, or string literals
  bool is_rhs_int = rhs->unary_expr_type == AST_UNARY_EXPR_INT_LITERAL;
  bool is_rhs_real = rhs->unary_expr_type == AST_UNARY_EXPR_REAL_LITERAL;
  bool is_rhs_str = rhs->unary_expr_type == AST_UNARY_EXPR_STR_LITERAL;

  // Ensure the condition is in the expected format
  if (!is_lhs_as || (!is_rhs_int && !is_rhs_real && !is_rhs_str)) {
    printf("ERROR: unsupported operand type(s) for !=\n");
    return false;
  }

  // Get the value of the left-hand side variable
  struct RAM_CELL *cell = ram_get_cell_by_id(memory, lhs->types.variable_name);
  if(cell == NULL){
    printf("ERROR: name '%s' is not defined\n", lhs->types.variable_name);
    return false;
  }
  else if ((cell->ram_cell_type == RAM_TYPE_INT || cell->ram_cell_type == RAM_TYPE_REAL) && is_rhs_str){
    printf("ERROR: unsupported operand type(s) for !=\n");
    return 0;
  }

  // Check for a not equal (!=) condition
  if (be->op == AST_BINARY_EXPR_NOT_EQUAL) {
    if (is_rhs_real && cell->ram_cell_type == RAM_TYPE_REAL) {
      double lhs_v = cell->types.d;
      double rhs_v = atof(rhs->types.literal_value);
      return lhs_v != rhs_v; // Compare and return the result
    } else if (is_rhs_int && cell->ram_cell_type == RAM_TYPE_INT) {
      int lhs_v = cell->types.i;
      int rhs_v = atoi(rhs->types.literal_value);
      return lhs_v != rhs_v; // Compare and return the result
    } else if (is_rhs_str) {
      char *str_lhs = cell->types.s;
      char *str_rhs = rhs->types.literal_value;
      return strcmp(str_lhs, str_rhs) != 0; // Compare and return the result
    }
  }

  return false; // Return false if no conditions matched
}

static bool while_loops(struct AST_STMT *stmt, struct RAM *memory) {
  bool success = false;
  int success2 = 2;

  if (stmt->stmt_type == AST_WHILE_LOOP) {
    struct AST_EXPR *cond = stmt->types.while_loop->condition;
    if(evaluate_while_cond(cond, memory) == false){
      return true;
    }
    // Evaluate the condition, and execute the loop while it's true
    while (evaluate_while_cond(cond, memory)) {
      struct AST_STMT *body = stmt->types.while_loop->body;
      while (body != NULL) {
        // Execute each statement in the loop's body
        if (body->stmt_type == AST_ASSIGNMENT) {
          success = execute_assignment(body, memory);
        } else if (body->stmt_type == AST_FUNCTION_CALL) {
          success = execute_function_call(body, memory);
        }
        else if(body->stmt_type == AST_WHILE_LOOP){
          success2 = while_loops(body, memory);
        }
        if(success == false || success2 == 0){
          return false;;
        }
        body = body->next;
      }

      // Optionally, you might want to print the memory state during each loop iteration
      // ram_print(memory);
    }
  }

  // Return the overall success status of the while loop
  return success;
}

//
// execute
//
// Executes the given nuPython program.
//
static void execute(struct AST_STMT *program, struct RAM *memory) {
  //
  // loop through the program stmt by stmt:
  //
  struct AST_STMT *cur = program;

  while (cur != NULL) {
    bool success = false;

    // printf("stmt type %d\n", cur->stmt_type);

    if (cur->stmt_type == AST_ASSIGNMENT) {
      success = execute_assignment(cur, memory);
    } else if (cur->stmt_type == AST_DEREF_PTR_ASSIGNMENT) {
      panic("deref ptr assignment not yet supported (execute)");
    } else if (cur->stmt_type == AST_FUNCTION_CALL) {
      success = execute_function_call(cur, memory);
    } else if (cur->stmt_type == AST_IF_THEN_ELSE) {
      panic("if-then-else not yet supported (execute)");
    } else if (cur->stmt_type == AST_WHILE_LOOP) {
      success = while_loops(cur, memory);
      // panic("while loops not yet supported (execute)");
    } else if (cur->stmt_type == AST_PASS) {
      //
      // pass => do nothing!
      //
    } else {
      panic("unknown statement type?! (execute)");
    }

    //
    // did execution fail?
    //
    if (!success) // yes, end execution:
      break;

    //
    // if execution was successful, advance to
    // next stmt:
    //
    cur = cur->next;
  }

  //
  // done:
  //
  
}

//
// main
//
int main(int argc, char *argv[]) {
  //
  // Ask the user for a filename, if they don't enter one
  // then we'll take input from the keyboard:
  //
  char filename[64];

  printf("Enter nuPython file (press ENTER to input from keyboard)>\n");

  fgets(filename, 64, stdin);                 // safely read at most 64 chars
  filename[strcspn(filename, "\r\n")] = '\0'; // delete EOL chars e.g. \n

  FILE *input = NULL;
  bool keyboardInput = false;

  if (strlen(filename) == 0) {
    //
    // input from the keyboard, aka stdin:
    //
    input = stdin;
    keyboardInput = true;
  } else {
    //
    // can we open the file?
    //
    input = fopen(filename, "r");

    if (input == NULL) // unable to open:
    {
      printf("**ERROR: unable to open input file '%s' for input.\n", filename);
      return 0;
    }

    keyboardInput = false;
  }

  //
  // input the tokens, either from keyboard or the given nuPython
  // file; the "input" variable controls the source. the scanner will
  // stop and return EOS when the user enters $ or we reach EOF on
  // the nuPython file:
  //

  //
  // setup for parsing and execution:
  //
  if (keyboardInput) // prompt the user if appropriate:
  {
    printf("nuPython input (enter $ when you're done)>\n");
  }

  parser_init();

  //
  // call parser to check program syntax:
  //
  struct TokenQueue *tokens = parser_parse(input);

  if (tokens == NULL) {
    //
    // program has a syntax error, error msg already output:
    //
    printf("**parsing failed, cannot execute\n");
  } else {
    printf("**parsing successful\n");
    printf("**building AST...\n");

    struct AST_STMT *program = ast_build(tokens);

    printf("**starting execution...\n");

    //
    // if program is coming from the keyboard, consume
    // the rest of the input after the $ before we
    // start executing the python:
    //
    if (keyboardInput) {
      int c = fgetc(stdin);
      while (c != '\n')
        c = fgetc(stdin);
    }

    //
    // now execute the nuPython program:
    //
    struct RAM *memory = ram_init();

    execute(program, memory);

    ram_print(memory);
    
    ram_free(memory);
    if (program != NULL) {
        ast_destroy(program);
    }
    tokenqueue_destroy(tokens);
  }
  
  //
  // done:
  //
  
  if (!keyboardInput)
    fclose(input);

  return 0;
}
