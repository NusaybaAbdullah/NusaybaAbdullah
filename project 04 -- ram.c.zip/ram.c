/*ram.c*/

//
// Project: random access memory (RAM) for nuPython
//
// Nusayba Abdullah
//
// initial template: Prof. Joe Hummel
// Northwestern University
// CS 211
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h> // true, false
#include <string.h>
#include <assert.h>

#include "util.h"
#include "ram.h"


//
// Public functions:
//

//
// ram_init
//
// Returns a pointer to a dynamically-allocated memory
// for storing nuPython variables and their values. All
// memory cells are initialized to the value None.
//
// ram_init
struct RAM* ram_init(void) {
  // Allocate memory for the RAM
  struct RAM* memory = (struct RAM*)malloc(sizeof(struct RAM));

  if (memory == NULL) {
      // Handle memory allocation failure gracefully
      return NULL;  // Return NULL if memory allocation fails
  }

  // Initialize RAM properties
  memory->memory_size = 4;
  memory->num_values = 0;

  // Allocate memory for RAM cells
  memory->cells = (struct RAM_CELL*)malloc(sizeof(struct RAM_CELL) * memory->memory_size);

  if (memory->cells == NULL) {
      // Handle cell allocation failure gracefully
      free(memory);  // Free previously allocated memory
      return NULL;   // Return NULL if cell allocation fails
  }

  // Initialize RAM cells
  for (int i = 0; i < memory->memory_size; ++i) {
      memory->cells[i].identifier = NULL;
      memory->cells[i].ram_cell_type = RAM_TYPE_NONE;
  }

  return memory;
}


// ram_free
void ram_free(struct RAM* memory) {
  if (memory == NULL) {
    return;  // Handle the case of already freed memory
  }

  for (int i = 0; i < memory->num_values; ++i) {
    struct RAM_CELL* cell = &memory->cells[i];
    if (cell->ram_cell_type == RAM_TYPE_STR) {
        free(cell->types.s);
    }
    if (cell->identifier != NULL) {
        free(cell->identifier);
    }
  }

  free(memory->cells);
  free(memory);
}

// ram_get_addr
int ram_get_addr(struct RAM* memory, char* identifier) {
    if (memory && identifier) {
        for (int i = 0; i < memory->num_values; ++i) {
            if (strcmp(memory->cells[i].identifier, identifier) == 0) {
                return i;
            }
        }
    }
    return -1;
}

// ram_get_cell_by_id
struct RAM_CELL* ram_get_cell_by_id(struct RAM* memory, char* identifier) {
    if (memory && identifier) {
        for (int i = 0; i < memory->num_values; ++i) {
            if (strcmp(memory->cells[i].identifier, identifier) == 0) {
                return &memory->cells[i];
            }
        }
    }
    return NULL;
}

// ram_get_cell_by_addr
struct RAM_CELL* ram_get_cell_by_addr(struct RAM* memory, int address) {
    if (address >= 0 && address < memory->num_values) {
        return &memory->cells[address];
    }
    return NULL;
}

//helper function to resize memory

struct RAM_CELL* increase_memory(struct RAM* memory, char* identifier) {
    int num = memory->num_values;

    // Resize memory if necessary
    if (num >= memory->memory_size) {
        memory->memory_size *= 2;
        struct RAM_CELL* cells = (struct RAM_CELL*)realloc(memory->cells, sizeof(struct RAM_CELL) * memory->memory_size);
        if (cells == NULL) {
            free(cells);
            return NULL;  // Return NULL in case of memory allocation failure
        }
        memory->cells = cells;
    }

    // Create a new cell
    struct RAM_CELL* cell = &memory->cells[num];
    cell->identifier = (char*)malloc(sizeof(char) * (strlen(identifier) + 1));
    strcpy(cell->identifier, identifier);

    // Increment num_values after resizing
    //memory->num_values++;

    return cell;
}
//helper function 2 to resize memory for writing by address
struct RAM_CELL* increase_cell_number(int address, struct RAM* memory){
  while (address >= memory->memory_size) {
      memory->memory_size *= 2;
  }

  // Resize the memory array using realloc
  struct RAM_CELL* new_cells = (struct RAM_CELL*)realloc(memory->cells, sizeof(struct RAM_CELL) * memory->memory_size);

  if (new_cells == NULL) {
      // Handle memory allocation failure 
      return NULL;
  }
  return new_cells;
}
// ram_write_int_by_id
void ram_write_int_by_id(struct RAM* memory, char* identifier, int value) {
    struct RAM_CELL* cell = ram_get_cell_by_id(memory, identifier);
    if (cell != NULL) {
      if(cell->ram_cell_type == RAM_TYPE_STR) {
        free(cell->types.s);
      }
      cell->types.i = value;
      cell->ram_cell_type = RAM_TYPE_INT;
    }
  else{
    cell = increase_memory(memory, identifier);
    cell->ram_cell_type = RAM_TYPE_INT;
    cell->types.i = value;
    memory->num_values++;
  }
}

// ram_write_int_by_addr
void ram_write_int_by_addr(struct RAM* memory, int address, int value) {
  if (memory == NULL || address < 0) {
    // Handle this error condition
    return;
  }

  if (address >= memory->memory_size) {
   
    // Update the memory cells to point to the new location
    memory->cells = increase_cell_number(address, memory);
  }

  if (memory->cells[address].identifier == NULL) {
    // If the cell does not exist at this address, create a new one
    memory->cells[address].identifier = NULL;  // Ensure it's NULL
    memory->num_values++;
  }

  // Update the cell at the specified address with the new integer value
  if(memory->cells[address].ram_cell_type == RAM_TYPE_STR){
    free(memory->cells[address].types.s); // Free the previous string if it exists
  }
  memory->cells[address].ram_cell_type = RAM_TYPE_INT;
  memory->cells[address].types.i = value;
}

// ram_write_real_by_id
void ram_write_real_by_id(struct RAM* memory, char* identifier, double value) {
  struct RAM_CELL* cell = ram_get_cell_by_id(memory, identifier);
  if(cell != NULL) {
    if(cell->ram_cell_type == RAM_TYPE_STR) {
      free(cell->types.s);
    }
    cell->types.d = value;
    cell->ram_cell_type = RAM_TYPE_REAL;
  }
  else{
    cell = increase_memory(memory, identifier);
    cell->ram_cell_type = RAM_TYPE_REAL;
    cell->types.d = value;
    memory->num_values++;
  }
}

// ram_write_real_by_addr
void ram_write_real_by_addr(struct RAM* memory, int address, double value) {
  if (memory == NULL || address < 0) {
    // Handle this error condition appropriately
    return;
  }

  if (address >= memory->memory_size) {
    memory->cells = increase_cell_number(address, memory);
  }

  if (memory->cells[address].identifier == NULL) {
    // If the cell does not exist at this address, create a new one
    memory->cells[address].identifier = NULL;  // Ensure it's NULL
    memory->num_values++;
  }

  // Update the cell at the specified address with the new real value
  if(memory->cells[address].ram_cell_type == RAM_TYPE_STR){
    free(memory->cells[address].types.s); // Free the previous string if it exists
  }
  memory->cells[address].ram_cell_type = RAM_TYPE_REAL;
  memory->cells[address].types.d = value;
}

// ram_write_str_by_id
void ram_write_str_by_id(struct RAM* memory, char* identifier, char* value) {
  struct RAM_CELL* cell = ram_get_cell_by_id(memory, identifier);
  if (cell != NULL) {
    if (cell->ram_cell_type == RAM_TYPE_STR) {
      free(cell->types.s); // Free the previous string if it exists
    }
    cell->types.s = (char*)malloc(sizeof(char) * (strlen(value) + 1));
    strcpy(cell->types.s, value);
    cell->ram_cell_type = RAM_TYPE_STR;
  } else {
    cell = increase_memory(memory, identifier);
    cell->ram_cell_type = RAM_TYPE_STR;
    cell->types.s = (char*)malloc(sizeof(char) * (strlen(value) + 1));
    strcpy(cell->types.s, value);
    memory->num_values++;
  }
}

// ram_write_str_by_addr
void ram_write_str_by_addr(struct RAM* memory, int address, char* value) {
  if (memory == NULL || address < 0) {
    // Handle this error condition
    return;
  }
  if (address >= memory->memory_size) {
    memory->cells = increase_cell_number(address, memory);
  }
  if (memory->cells[address].identifier == NULL) {
    // If the cell does not exist at this address, create a new one
    memory->cells[address].identifier = NULL;  // Ensure it's NULL
    memory->num_values++;
  }
  // Update the cell at the specified address with the new string value
  if(memory->cells[address].ram_cell_type == RAM_TYPE_STR){
    free(memory->cells[address].types.s); // Free the previous string if it exists
  }
  memory->cells[address].ram_cell_type = RAM_TYPE_STR;
  memory->cells[address].types.s = (char*)malloc(sizeof(char) * (strlen(value) + 1));
  strcpy(memory->cells[address].types.s, value);
}

// ram_write_ptr_by_id
void ram_write_ptr_by_id(struct RAM* memory, char* identifier, int value) {
  ram_write_int_by_id(memory, identifier, value);
  struct RAM_CELL *cell = ram_get_cell_by_id(memory, identifier);
  cell->ram_cell_type = RAM_TYPE_PTR;
  
}

// ram_write_ptr_by_addr
void ram_write_ptr_by_addr(struct RAM* memory, int address, int value) {
  ram_write_int_by_addr(memory, address, value);
  memory->cells[address].ram_cell_type = RAM_TYPE_PTR;
}

//
// ram_print
//
// Prints the contents of memory to the console.
//
void ram_print(struct RAM* memory)
{
  printf("**MEMORY PRINT**\n");

  printf("Size: %d\n", memory->memory_size);
  printf("Num values: %d\n", memory->num_values);
  printf("Contents:\n");

  for (int i = 0; i < memory->num_values; i++)
  {
    printf(" %d: %s, ", i, memory->cells[i].identifier);

    if (memory->cells[i].ram_cell_type == RAM_TYPE_INT)
      printf("int, %d", memory->cells[i].types.i);
    else if (memory->cells[i].ram_cell_type == RAM_TYPE_REAL)
      printf("real, %lf", memory->cells[i].types.d);
    else if (memory->cells[i].ram_cell_type == RAM_TYPE_STR)
      printf("str, '%s'", memory->cells[i].types.s);
    else if (memory->cells[i].ram_cell_type == RAM_TYPE_PTR)
      printf("ptr, %d", memory->cells[i].types.i);
    else if (memory->cells[i].ram_cell_type == RAM_TYPE_BOOLEAN)
    {
      if (memory->cells[i].types.i == 0)
        printf("int, False");
      else
        printf("int, True");
    }
    else if (memory->cells[i].ram_cell_type == RAM_TYPE_NONE)
      printf("none, None");
    else
      panic("unknown ram cell type?! (ram_print)");

    printf("\n");
  }

  printf("**END PRINT**\n");
}

