/*BusStops.cpp*/
//
// A collection of bus stops from the txt file.
// 
// Prof. Joe Hummel
// Northwestern University
// CS 211
// Nusayba Abdullah
#include <iostream>
#include <utility>
#include <algorithm>
#include <string>
#include "BusStops.h"
#include <fstream>
#include <sstream>
#include <vector>
using namespace std;


void BusStops::readBusStops(string filename){
    ifstream input(filename);
    string line;

    
    while(getline(input, line)){
        //getline(input, line);
        stringstream parser(line);
        
        string id, route, name, direction, loc, coor1, coor2;

        getline(parser, id, ',');
        getline(parser, route, ',');
        getline(parser, name, ',');
        getline(parser, direction, ',');
        getline(parser, loc, ',');
        getline(parser, coor1, ',');
        getline(parser, coor2, ',');

        int idNew = stoi(id);
        int routeNew = stoi(route);
        double coor1New = stod(coor1);
        double coor2New = stod(coor2);
        pair<double, double > coors = make_pair(coor1New, coor2New);

        this->AllBusStops.emplace_back(idNew, routeNew, name, direction, loc, coors);
    }
    this->count = this->AllBusStops.size();
}

bool BusStops::idSort(BusStop a, BusStop b){
    return a.stopID < b.stopID;
}
bool BusStops::directionSort(BusStop a, BusStop b){
    return a.direction < b.direction;
}
void BusStops::printAll(){
    sort(this->AllBusStops.begin(), this->AllBusStops.end(), idSort);
    for(BusStop b: this->AllBusStops){
        b.print();
    }
}
//helper function to look at only southbound busses
vector<BusStop> BusStops::sortSouthbound(){
    vector<BusStop> sorted;
    for(BusStop bs: this->AllBusStops){
        if(bs.direction == "Southbound"){
            sorted.emplace_back(bs);
        }
    }
    return sorted;
}
//helper for the northbound busses
vector<BusStop> BusStops::sortNorthbound(){
    vector<BusStop> sorted;
    for(BusStop bs: this->AllBusStops){
        if(bs.direction == "Northbound"){
            sorted.emplace_back(bs);
        }
    }
    return sorted;
}
