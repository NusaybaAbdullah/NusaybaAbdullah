/*buildings.cpp*/

//
// A collection of buildings in the Open Street Map.
// 
// Prof. Joe Hummel
// Northwestern University
// CS 211
// 

#include <iostream>
#include <string>
#include <vector>
#include <cassert>
#include <algorithm>
#include "buildings.h"
#include "nodes.h"
#include "osm.h"
#include "tinyxml2.h"

using namespace std;
using namespace tinyxml2;


//
// readMapBuildings
//
// Given an XML document, reads through the document and 
// stores all the buildings into the given vector.
//
void Buildings::readMapBuildings(XMLDocument& xmldoc)
{
  XMLElement* osm = xmldoc.FirstChildElement("osm");
  assert(osm != nullptr);

  //
  // Parse the XML document way by way, looking for university buildings:
  //
  XMLElement* way = osm->FirstChildElement("way");

  while (way != nullptr)
  {
    const XMLAttribute* attr = way->FindAttribute("id");
    assert(attr != nullptr);

    //
    // if this is a building, store info into vector:
    //
    if (osmContainsKeyValue(way, "building", "university"))
    {
      string name = osmGetKeyValue(way, "name");

      string streetAddr = osmGetKeyValue(way, "addr:housenumber")
        + " "
        + osmGetKeyValue(way, "addr:street");

      //
      // create building object, then add the associated
      // node ids to the object:
      //
      long long id = attr->Int64Value();

      Building B(id, name, streetAddr);

      XMLElement* nd = way->FirstChildElement("nd");

      while (nd != nullptr)
      {
        const XMLAttribute* ndref = nd->FindAttribute("ref");
        assert(ndref != nullptr);

        long long id = ndref->Int64Value();

        B.add(id);

        // advance to next node ref:
        nd = nd->NextSiblingElement("nd");
      }

      //
      // add the building to the vector:
      //
      this->MapBuildings.push_back(B);
    }//if

    way = way->NextSiblingElement("way");
  }//while

  //
  // done:
  //
}

//
// print
//
// prints each building (id, name, address) to the console.
//
void Buildings::print()
{
  for (const Building& B : this->MapBuildings) {
    cout << B.ID << ": " << B.Name << ", " << B.StreetAddress << endl;
  }
}

//
// findAndPrint
//
// Prints each building that contains the given name.
//
void Buildings::findAndPrint(string name, Nodes& nodes, CURL* curl)
{
  // 
  // find every building that contains this name:
  //
  for (Building& B : this->MapBuildings)
  {
    if (B.Name.find(name) != string::npos) { // contains name:
      cout << B.Name << endl;
      cout << "Address: " << B.StreetAddress << endl;
      cout << "Building ID: " << B.ID << endl;
      cout << "# perimeter nodes: " << B.NodeIDs.size() << endl;
      cout << "Location: ";
      cout << "(" << B.getLocation(nodes).first << ", "<< B.getLocation(nodes).second << ")" << endl;

      closest(B, nodes, curl);
      //B.print(nodes);
      
    }
  }
}

//
// accessors / getters
//
int Buildings::getNumMapBuildings() {
  return (int) this->MapBuildings.size();
}
//
// closest
//
// Finds the closest northbound and southbound bus stops to a given building,
// calculates the distances, and prints information about the closest stops.
// Parameters:
// - b: The Building object for which to find the closest bus stops.
// - nodes: Nodes object containing information about map nodes.
// - curl: CURL pointer for making web requests.
//
void Buildings::closest(Building b, const Nodes& nodes, CURL* curl) {
    // Sort bus stops into northbound and southbound vectors
    vector<BusStop> southbound = this->bs.sortSouthbound();
    vector<BusStop> northbound = this->bs.sortNorthbound();

    // Get latitude and longitude of the building
    double lat1 = b.getLocation(nodes).first;
    double lon1 = b.getLocation(nodes).second;

    // Initialize variables for distances and closest bus stops
    double nlat = northbound[0].position.first;
    double nlon = northbound[0].position.second;
    double slat = southbound[0].position.first;
    double slon = southbound[0].position.second;
    double distn = distBetween2Points(lat1, lon1, nlat, nlon);
    double dists = distBetween2Points(lat1, lon1, slat, slon);
    double minn = distn;
    double mins = dists;
    BusStop cn = northbound[0];
    BusStop cs = southbound[0];

    // Iterate through northbound bus stops to find the closest one
    for (BusStop bs2 : northbound) {
        nlat = bs2.position.first;
        nlon = bs2.position.second;
        distn = distBetween2Points(lat1, lon1, nlat, nlon);

        if (distn < minn) {
            minn = distn;
            cn = bs2;
        }
    }

    // Iterate through southbound bus stops to find the closest one
    for (BusStop bs2 : southbound) {
        slat = bs2.position.first;
        slon = bs2.position.second;
        dists = distBetween2Points(lat1, lon1, slat, slon);

        if (dists < mins) {
            mins = dists;
            cs = bs2;
        }
    }

    // Print information about the closest southbound and northbound bus stops
    cout << "Closest southbound bus stop:" << endl;
    cs.printStopInfo(mins, curl);
    cout << "Closest northbound bus stop:" << endl;
    cn.printStopInfo(minn, curl);

}