/*BusStops.h*/

//
// A collection of bus stops.
// 
// Prof. Joe Hummel
// Northwestern University
// CS 211
// Nusayba Abdullah

#pragma once

#include <string>
#include <vector>
#include <utility>
#include "node.h"
#include "nodes.h"
#include "BusStop.h"
#include "dist.h"
using namespace std;


//
// Bus stops
//
// Defines a collection of bus stops read from file
// 
//
//
class BusStops{
    public:
        vector<BusStop> AllBusStops;
        //vector with 1st element being southbound bus and 2nd element being northbound
        int count;
        void readBusStops (string filename);
        static bool idSort (BusStop a, BusStop b);
        static bool directionSort (BusStop a, BusStop b);
        void printAll();
        vector<BusStop> sortSouthbound ();
        vector<BusStop> sortNorthbound ();
        

    

};