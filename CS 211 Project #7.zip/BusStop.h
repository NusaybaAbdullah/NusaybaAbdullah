/*BusStop.h*/

//
// A bus stop in the Open Street Map.
// 
// Prof. Joe Hummel
// Northwestern University
// CS 211
// Nusayba Abdullah

#pragma once

#include <string>
#include <vector>
#include <utility>
#include "node.h"
#include "nodes.h"
#include "curl_util.h"
#include <curl/curl.h>
#include "json.hpp"


using json = nlohmann::json;
using namespace std;


//
// Bus stop
//
// Defines a bus stop with a street name (e.g. "Sheridan"), a direction, and the IDs of the nodes that
//  and location.
// 
//
//
class BusStop
{
public:
  long long stopID;
  int busRoute;
  string stopName;
  string direction;
  string stopLocation;
  pair<double, double> position;

  //
  // constructor
  //
  BusStop(int stopID, int busRoute, string stopName, string direction, string stopLocation, pair<double, double> position);

 
  // print
  // 
  // prints information about a busStop --- id, name, etc. -- to
  // the console. 
  //
  void print();
  //this function prints out the prediction information (takes in the distance to print
  //out the closest bus and then the curl object to output the predictions)
  void printStopInfo(double dist, CURL* curl);

};