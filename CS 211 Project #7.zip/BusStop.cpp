/*BusStop.cpp*/
//
// A bus stop from the txt file.
// 
// Prof. Joe Hummel
// Northwestern University
// CS 211
// Nusayba Abdullah
#include <iostream>
#include <utility>
#include <string>
#include "BusStop.h"
#include "curl_util.h"
#include <curl/curl.h>
#include "json.hpp"

using namespace std;

//
// BusStop constructor
//
// Initializes a BusStop object with the provided parameters.
// Parameters:
// - stopID: Unique identifier for the bus stop.
// - busRoute: Bus route number associated with the stop.
// - stopName: Name of the bus stop.
// - direction: Direction of the bus stop.
// - stopLocation: Location description of the bus stop.
// - position: Pair of latitude and longitude coordinates representing the stop's location.
//
BusStop::BusStop(int stopID, int busRoute, string stopName, string direction, string stopLocation, pair<double, double> position)
{
    // Initialize BusStop object using member initialization list
    this->stopID = stopID;
    this->busRoute = busRoute;
    this->stopName = stopName;
    this->direction = direction;
    this->stopLocation = stopLocation;
    this->position = position;
}

//
// print
//
// Prints basic information about the BusStop object.
// Outputs the stop ID, bus route, stop name, direction, stop location,
// and geographical coordinates of the stop.
//
void BusStop::print() {
    cout << this->stopID << ": bus " << this->busRoute << ", ";
    cout << this->stopName << ", " << this->direction << ", ";
    cout << this->stopLocation << ", " << "location " <<
        "(" << this->position.first << ", " << this->position.second << ")"
        << endl;
}

//
// printStopInfo
//
// Prints detailed information about the BusStop object, including
// distance from a reference point and bus arrival predictions.
// Parameters:
// - dist: Distance from the reference point to the bus stop.
// - curl: CURL pointer for making web requests.
//
void BusStop::printStopInfo(double dist, CURL* curl) {
    cout << "  ";
    cout << this->stopID << ": " << this->stopName <<
        ", " << "bus #" << this->busRoute << ", " << this->stopLocation << ", " << dist << " miles\n";
    // Output bus arrival predictions

    // API key for accessing the CTA bus tracker API
    string apiKey = "XeC9Cx3Z5n7f7LrzRfVkkmxvj";
    int busRouteNumber = this->busRoute;
    int busStopID = this->stopID;

    // Construct the API URL for bus predictions
    string apiUrl = "http://www.ctabustracker.com/bustime/api/v2/getpredictions?key=" +
        apiKey + "&rt=" + to_string(busRouteNumber) +
        "&stpid=" + to_string(busStopID) + "&format=json";
    string response;

    // Make the API call and handle failures
    if (!callWebServer(curl, apiUrl, response)) {
        cout << "<<bus predictions unavailable, call failed>" << endl;
    } else {
        auto jsondata = json::parse(response);

        // Check if keys exist and the array is not empty
        if (jsondata.find("bustime-response") != jsondata.end() &&
            jsondata["bustime-response"].find("prd") != jsondata["bustime-response"].end() &&
            !jsondata["bustime-response"]["prd"].empty()) {

            auto predictions = jsondata["bustime-response"]["prd"];

            for (auto& M : predictions) {
                // Check if predicted time is available
                if (stoi(M["prdctdn"].get_ref<std::string&>())) {
                    // Access individual fields in each prediction
                    cout << "  vehicle #" << stoi(M["vid"].get_ref<std::string&>());
                    cout << " on route " << stoi(M["rt"].get_ref<std::string&>()) <<
                        " travelling " << M["rtdir"].get_ref<std::string&>() << " to arrive in " << stoi(M["prdctdn"].get_ref<std::string&>()) << " mins\n";
                } else {
                    cout << "  <<no predictions available>>" << endl;
                }
            }
        } else {
            cout << "  <<no predictions available>>" << endl;
        }
    }
}